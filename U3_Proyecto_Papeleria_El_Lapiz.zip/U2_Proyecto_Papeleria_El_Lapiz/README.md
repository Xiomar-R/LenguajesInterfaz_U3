# U2 Proyecto: Ventas e inventario en ensamblador

Sistema de ventas e inventario para la Papelería "El Lápiz", en MASM x86 de 32 bits con Irvine32.

**Materia:** Lenguajes de Interfaz · **Docente:** Dr. José Luis Medina Jiménez · **Horario:** 8:00 a 9:00

**Integrantes:**
- Angulo Ramírez Eber Xiomar
- Romero Adrián Juan Ramón
- Urrea Esquerra Héctor Manuel

## Archivos

| Archivo | Contenido |
|---|---|
| `U2_Proyecto_Papeleria.asm` | Código fuente |
| `practica1.vcxproj`, `practica1.vcxproj.filters` | Proyecto de Visual Studio |
| `inventario.txt` | Inventario de prueba con 4 productos |
| `Informe_U2_Papeleria_El_Lapiz.pdf` | Informe y tabla de pruebas |

## Compilación y ejecución

Requisitos: Visual Studio con la carga de trabajo "Desarrollo para el escritorio con C++" y la biblioteca Irvine32 instalada en `C:\Irvine`.

1. Abrir `practica1.vcxproj` con Visual Studio.
2. Seleccionar la configuración **Debug** y la plataforma **x86 (Win32)**.
3. Compilar con **Compilar → Compilar solución** (Ctrl+Shift+B).
4. Ejecutar con **Depurar → Iniciar sin depurar** (Ctrl+F5).

Al iniciar, el programa carga `inventario.txt` de la carpeta del proyecto, que es el directorio de trabajo cuando se ejecuta desde Visual Studio. La opción 7 guarda el catálogo en ese mismo archivo.

## Formato de `inventario.txt`

Una línea por producto, con los campos separados por `|`:

```
CODIGO|NOMBRE|PRECIO_EN_CENTAVOS|EXISTENCIA
CUA-001|Cuaderno profesional|4550|30
```
